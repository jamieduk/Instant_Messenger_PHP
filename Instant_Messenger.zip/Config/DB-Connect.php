<?php
//
$db = new mysqli("localhost", "root", "pass", "Instant_Messeger");
