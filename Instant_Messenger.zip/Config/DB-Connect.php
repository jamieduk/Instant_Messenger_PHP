<?php
//
$db = new mysqli("localhost", "root", "password", "Instant_Messeger");
